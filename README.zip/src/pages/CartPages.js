import React from "react";
import { Cart } from "../features/cart/Cart";

const CartPages = () => {
  return (
    <div>
      <Cart />
    </div>
  );
};

export default CartPages;
