import React from "react";
import Navbar from "../features/navbar/Navbar";
import { ProductList } from "../features/product/components/ProductList";
import Footer from "../constants/Footer";
import { useSelector } from "react-redux";
import { selectStatus } from "../features/product/productListSlice";

const Home = () => {
  const status = useSelector(selectStatus);
  return (
    <div>
      <Navbar>
        <ProductList></ProductList>
      </Navbar>
      {status === "idle" && <Footer />}
    </div>
  );
};

export default Home;
